import os
import fnmatch
import ffmpeg
##https://blog.csdn.net/leixiaohua1020/article/details/12751349


rootDir = "E:/zhaoqinglong/branch_skins_jinzhong_remove_resource/Skins"
includes = ["*.mp3"]
for root, dirs, files in os.walk(rootDir, topdown=True):
    for pat in includes:
        for f in fnmatch.filter(files, pat):
			path = os.path.join(root, f)
			outpath = os.path.join(root, os.path.splitext(f)[0]+"_new.mp3")
			os.system("ffmpeg -i "+path+" -ar 16000 -y "+outpath)
			os.system("rm -f "+path)
			os.system("mv "+outpath+" "+path)
            